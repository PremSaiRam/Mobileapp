import React from 'react';
import { View, FlatList, Text, TouchableOpacity } from 'react-native';

const courses = [
  { id: '1', title: 'React Native Basics', description: 'Learn to build mobile apps.' },
  { id: '2', title: 'Business Communication', description: 'Improve your soft skills.' },
];

const CourseCatalogScreen = ({ navigation }) => (
  <View>
    <FlatList
      data={courses}
      keyExtractor={item => item.id}
      renderItem={({ item }) => (
        <TouchableOpacity onPress={() => navigation.navigate('CourseDetail', { course: item })}>
          <View style={{ padding: 20, borderBottomWidth: 1 }}>
            <Text style={{ fontSize: 18 }}>{item.title}</Text>
            <Text style={{ color: '#666' }}>{item.description}</Text>
          </View>
        </TouchableOpacity>
      )}
    />
  </View>
);

export default CourseCatalogScreen;