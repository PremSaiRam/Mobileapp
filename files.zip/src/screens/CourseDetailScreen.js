import React from 'react';
import { View, Text, Button } from 'react-native';

const CourseDetailScreen = ({ route, navigation }) => {
  const { course } = route.params;
  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 22 }}>{course.title}</Text>
      <Text>{course.description}</Text>
      <Button title="Start Lesson" onPress={() => navigation.navigate('Lesson', { courseId: course.id })} />
    </View>
  );
};

export default CourseDetailScreen;