import React from 'react';
import { View, Text, Button } from 'react-native';

const HomeScreen = ({ navigation }) => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold' }}>Welcome to Learning App!</Text>
    <Button title="Browse Courses" onPress={() => navigation.navigate('Catalog')} />
    <Button title="My Profile" onPress={() => navigation.navigate('Profile')} />
  </View>
);

export default HomeScreen;