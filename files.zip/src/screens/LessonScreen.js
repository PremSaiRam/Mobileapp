import React from 'react';
import { View, Text, Button } from 'react-native';

const lesson = {
  title: 'Introduction',
  content: 'Welcome to the first lesson. This is where the learning begins!',
};

const LessonScreen = ({ navigation }) => (
  <View style={{ padding: 20 }}>
    <Text style={{ fontSize: 20 }}>{lesson.title}</Text>
    <Text style={{ marginVertical: 20 }}>{lesson.content}</Text>
    <Button title="Take Quiz" onPress={() => navigation.navigate('Quiz')} />
  </View>
);

export default LessonScreen;