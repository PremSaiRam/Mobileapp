import React from 'react';
import { View, Text } from 'react-native';

const ProfileScreen = () => (
  <View style={{ padding: 20 }}>
    <Text style={{ fontSize: 22 }}>My Profile</Text>
    <Text>Name: John Doe</Text>
    <Text>Courses Completed: 2</Text>
    <Text>Badges: Beginner, Communicator</Text>
  </View>
);

export default ProfileScreen;