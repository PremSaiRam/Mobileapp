import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

const questions = [
  { id: 1, question: 'What framework is used here?', answer: 'React Native' },
];

const QuizScreen = () => {
  const [showAnswer, setShowAnswer] = useState(false);
  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 18 }}>{questions[0].question}</Text>
      {showAnswer && <Text style={{ marginVertical: 10, color: 'green' }}>{questions[0].answer}</Text>}
      <Button title="Show Answer" onPress={() => setShowAnswer(true)} />
    </View>
  );
};

export default QuizScreen;